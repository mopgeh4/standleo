# Standleo Visual Demo

Минимальный Android-проект на Java для Android Studio.

## Что есть
- Экран с переключателями Potato Graphics и Night Mode (визуальные настройки демо-сцены).
- Демонстрационные трассеры.
- Радар с искусственными точками.

## Важно
Это самостоятельное демо-приложение. Оно не внедряется в Standoff 2/Standleo Classic, не считывает память других процессов и не показывает реальные позиции игроков.

## Сборка APK
1. Распакуйте архив.
2. Откройте папку `StandleoVisualDemo` в Android Studio.
3. Дождитесь Gradle Sync (нужны Android SDK Platform 35 и Android Gradle Plugin 8.7.3).
4. Выберите **Build > Build APK(s)**.
5. APK обычно появится в `app/build/outputs/apk/debug/app-debug.apk`.

JDK 17 рекомендуется.
