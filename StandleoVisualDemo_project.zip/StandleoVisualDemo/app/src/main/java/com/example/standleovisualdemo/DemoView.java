package com.example.standleovisualdemo;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Color;
import android.graphics.RectF;
import android.view.View;

public class DemoView extends View {
    private final Paint p = new Paint(3);
    private java.util.function.Supplier<boolean[]> state = () -> new boolean[]{false,false,true,true};

    public DemoView(Context context) { super(context); setLayerType(View.LAYER_TYPE_SOFTWARE, null); }
    public void setStateSupplier(java.util.function.Supplier<boolean[]> supplier) { state = supplier; }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        boolean[] s = state.get();
        boolean potato = s[0], night = s[1], tracers = s[2], radar = s[3];
        int bg = night ? Color.rgb(7, 10, 18) : (potato ? Color.rgb(75, 82, 73) : Color.rgb(31, 38, 48));
        c.drawColor(bg);
        float w = getWidth(), h = getHeight();
        p.setColor(night ? Color.rgb(38, 49, 66) : Color.rgb(59, 71, 78));
        p.setStyle(Paint.Style.FILL);
        c.drawRoundRect(new RectF(w*.08f,h*.08f,w*.92f,h*.92f), 22,22,p);
        p.setColor(night ? Color.rgb(74, 99, 123) : Color.rgb(109, 123, 110));
        for (int i=0;i<6;i++) {
            float x = w*(.16f+i*.13f);
            c.drawRect(x,h*.18f,x+w*.055f,h*.76f,p);
        }
        p.setColor(Color.WHITE); p.setTextSize(13);
        c.drawText("ТЕСТОВАЯ СЦЕНА", w*.12f, h*.14f, p);

        if (tracers) {
            p.setColor(Color.rgb(255, 190, 60)); p.setStrokeWidth(3);
            c.drawLine(w*.5f,h*.83f,w*.32f,h*.38f,p);
            c.drawLine(w*.5f,h*.83f,w*.66f,h*.49f,p);
            p.setStyle(Paint.Style.FILL);
            c.drawCircle(w*.32f,h*.38f,5,p);
            c.drawCircle(w*.66f,h*.49f,5,p);
        }
        if (radar) {
            float cx=w*.76f, cy=h*.27f, r=Math.min(w,h)*.13f;
            p.setColor(Color.argb(210, 10, 15, 20)); p.setStyle(Paint.Style.FILL);
            c.drawCircle(cx,cy,r,p);
            p.setColor(Color.rgb(100,210,170)); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.5f);
            c.drawCircle(cx,cy,r,p); c.drawLine(cx-r,cy,cx+r,cy,p); c.drawLine(cx,cy-r,cx,cy+r,p);
            p.setStyle(Paint.Style.FILL); p.setColor(Color.rgb(255,100,100));
            c.drawCircle(cx-r*.35f,cy-r*.25f,4,p); c.drawCircle(cx+r*.4f,cy+r*.3f,4,p);
            p.setColor(Color.WHITE); p.setTextSize(10); c.drawText("DEMO",cx-r*.55f,cy+r+14,p);
        }
        p.setColor(Color.WHITE); p.setTextSize(12);
        c.drawText("Potato Graphics: " + (potato ? "ON" : "OFF"), w*.12f,h*.88f,p);
    }
}
