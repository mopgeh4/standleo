package com.example.standleovisualdemo;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private DemoView demoView;
    private boolean potato = false;
    private boolean night = false;
    private boolean tracers = true;
    private boolean radar = true;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(18));
        root.setBackgroundColor(Color.rgb(16, 18, 24));

        TextView title = new TextView(this);
        title.setText("Standleo Visual Demo");
        title.setTextColor(Color.WHITE);
        title.setTextSize(24);
        title.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(52)));

        TextView subtitle = new TextView(this);
        subtitle.setText("Отдельная демонстрация • не подключается к игре");
        subtitle.setTextColor(Color.LTGRAY);
        subtitle.setTextSize(13);
        root.addView(subtitle, new LinearLayout.LayoutParams(-1, dp(34)));

        demoView = new DemoView(this);
        root.addView(demoView, new LinearLayout.LayoutParams(-1, 0, 1));

        addToggle(root, "Potato Graphics: ", () -> potato, v -> potato = v);
        addToggle(root, "Night Mode: ", () -> night, v -> night = v);
        addToggle(root, "Tracers (демо): ", () -> tracers, v -> tracers = v);
        addToggle(root, "Radar (искусственные точки): ", () -> radar, v -> radar = v);

        TextView note = new TextView(this);
        note.setText("Все точки и трассеры синтетические. Приложение не читает память других приложений и не взаимодействует со Standoff 2.");
        note.setTextColor(Color.GRAY);
        note.setTextSize(12);
        note.setPadding(0, dp(12), 0, 0);
        root.addView(note);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);
        setContentView(scroll);
        demoView.setStateSupplier(() -> new boolean[]{potato, night, tracers, radar});
    }

    private interface BoolGet { boolean get(); }
    private interface BoolSet { void set(boolean value); }

    private void addToggle(LinearLayout root, String label, BoolGet getter, BoolSet setter) {
        Button button = new Button(this);
        button.setAllCaps(false);
        Runnable update = () -> button.setText(label + (getter.get() ? "ВКЛ" : "ВЫКЛ"));
        update.run();
        button.setOnClickListener(v -> {
            setter.set(!getter.get());
            update.run();
            demoView.invalidate();
        });
        root.addView(button, new LinearLayout.LayoutParams(-1, dp(48)));
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
}
